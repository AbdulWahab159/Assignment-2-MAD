# Flutter Assignment 2

A Flutter mobile application demonstrating:
- Animated splash screen
- Home screen and drawer navigation
- Main page with ListView
- About page with GridView

## Open in Android Studio
1. Extract this ZIP file.
2. In Android Studio choose **Open** and select the `flutter_assignment2` folder (the folder containing `pubspec.yaml`).
3. Wait for Flutter/Dart setup, then run `flutter pub get` in the terminal.
4. Start an Android emulator or connect an Android phone with USB debugging enabled.
5. Run `flutter run`.

The iOS folder is included for project structure; building iOS apps requires macOS and Xcode.
