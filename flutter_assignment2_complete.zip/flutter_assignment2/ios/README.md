The iOS source scaffold is included. On macOS with Xcode installed, run `flutter create --platforms=ios .` from the project root if a full Xcode Runner project is needed.
