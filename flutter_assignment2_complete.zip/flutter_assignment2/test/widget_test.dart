import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_assignment2/main.dart';

void main() {
  testWidgets('App starts with splash screen', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    expect(find.text('My Flutter App'), findsOneWidget);
    expect(find.text('Welcome to my application'), findsOneWidget);
  });
}
